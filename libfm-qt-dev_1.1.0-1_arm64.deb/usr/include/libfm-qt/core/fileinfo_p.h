#ifndef FILEINFO_P_H
#define FILEINFO_P_H

namespace Fm {

    extern const char defaultGFileInfoQueryAttribs[];

} // namespace Fm

#endif // FILEINFO_P_H
